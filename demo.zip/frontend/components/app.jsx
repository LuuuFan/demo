import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { AuthRoute, ProtectedRoute } from '../util/route_util';
import HomeContainer from './home/home_container';
import SessionFormContainer from './session/session_form_container';
import { Security, ImplicitCallback } from '@okta/okta-react';

const config = {
  issuer: 'https://dev-772839.oktapreview.com/oauth2/default',
  redirect_uri: window.location.origin + '/implicit/callback',
  client_id: '0oag546kkrj3ZXEeW0h7',
}

const App = () => (
  <div className = 'main'>
    <Switch>
		<ProtectedRoute exact path='/' component = { HomeContainer } />
		<AuthRoute path='/signup' component={SessionFormContainer} />
		<AuthRoute path='/login' component={SessionFormContainer} />
    </Switch>  
  </div>
);

export default App;