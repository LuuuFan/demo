export const TOGGLE_CHAT = 'TOGGLE_CHAT';


export const toggleChat = () => ({
	type: TOGGLE_CHAT
});